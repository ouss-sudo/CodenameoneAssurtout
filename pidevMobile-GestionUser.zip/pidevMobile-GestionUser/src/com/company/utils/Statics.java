/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.company.utils;

/**
 *
 * @author lordg
 */
public class Statics {
    public static final String BASE_URL="http://127.0.0.1:8000";
     public static final String URL_UPLOAD =BASE_URL+ "imageServer.php";
    public static final String URL_REP_IMAGES =BASE_URL + "images/";
}
